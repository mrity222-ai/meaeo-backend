"use client";

import { use, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  ArrowUpRight,
  BarChart3,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock,
  Clock3,
  Copy,
  Edit3,
  Eye,
  Facebook,
  Heart,
  Instagram,
  Linkedin,
  Menu,
  MessageSquare,
  MoreHorizontal,
  Pause,
  Play,
  Plus,
  RefreshCw,
  Share2,
  Sparkles,
  Store,
  Target,
  TrendingUp,
  Zap,
} from "lucide-react";

import { DashboardSidebar } from "@/components/navigation/dashboard-sidebar";

const campaignData = {
  id: "1",
  name: "September Growth Campaign",
  objective: "Increase brand awareness, drive social engagement, and capture Q4 demo requests.",
  status: "Running",
  progress: 68,
  startDate: "Sep 1, 2026",
  endDate: "Sep 30, 2026",
  reach: "18.4K",
  engagement: "8.6%",
  postsPublished: "17 / 25",
  clicks: "1,420",
  conversions: "184",
  platforms: ["Instagram", "LinkedIn", "Facebook", "Google Business (GMB)"],
};

const lifecycleSteps = [
  { name: "Strategy", status: "completed" },
  { name: "Content Gen", status: "completed" },
  { name: "Review", status: "completed" },
  { name: "Scheduled", status: "active" },
  { name: "Publishing", status: "pending" },
  { name: "Optimization", status: "pending" },
];

const generatedPosts = [
  {
    id: "post-1",
    title: "5 AI Strategies Every Marketer Needs in 2026",
    platform: "LinkedIn",
    time: "Today · 6:30 PM",
    status: "Scheduled",
    copy: "Autonomous AI is revolutionizing how modern marketing teams scale campaign output. Here are 5 battle-tested strategies to boost your reach by 3x...",
    likes: "1.4K",
    comments: "342",
  },
  {
    id: "post-2",
    title: "How autonomous marketing scaled our demo requests by 3x",
    platform: "Instagram",
    time: "Tomorrow · 10:00 AM",
    status: "Requires Review",
    copy: "Struggling with post consistency? Learn how setting up automated campaign workflows allowed our team to publish 4x faster without sacrificing quality.",
    likes: "2.1K",
    comments: "198",
  },
  {
    id: "post-3",
    title: "Behind the scenes: Prompt-to-campaign workflow demo",
    platform: "Facebook",
    time: "Sep 12 · 4:00 PM",
    status: "Draft",
    copy: "Watch how simple inputs turn into a multi-platform content strategy in under 60 seconds with our autonomous AI engine.",
    likes: "980",
    comments: "156",
  },
];

const aiLogs = [
  {
    title: "Peak engagement window detected",
    time: "2 hours ago",
    description: "Adjusted LinkedIn posting slot to 6:30 PM based on past 30-day audience activity trends.",
  },
  {
    title: "Hashtag strategy optimized",
    time: "1 day ago",
    description: "Replaced 3 low-performing tags with high-intent industry keywords on Instagram post #18.",
  },
  {
    title: "Content variant generated",
    time: "2 days ago",
    description: "Created 3 caption variations optimized for LinkedIn carousel engagement.",
  },
];

export default function CampaignDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const resolvedParams = use(params);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isRunning, setIsRunning] = useState(campaignData.status === "Running");

  return (
    <div className="min-h-screen bg-white text-neutral-950">
      <DashboardSidebar
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <main className="min-h-screen md:pl-[230px]">
        {/* Mobile Header */}
        <header className="sticky top-0 z-40 flex h-16 items-center justify-between border-b border-neutral-200 bg-white px-4 md:hidden">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              aria-label="Open menu"
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-50"
            >
              <Menu size={19} />
            </button>
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-full bg-neutral-950 text-white">
                <Sparkles size={14} />
              </div>
              <span className="text-sm font-semibold">Marketing System</span>
            </div>
          </div>
        </header>

        {/* Desktop Header */}
        <div className="hidden h-16 items-center justify-between border-b border-neutral-200 px-7 md:flex">
          <div className="flex items-center gap-3">
            <Link
              href="/campaigns"
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-neutral-200 text-neutral-600 transition hover:bg-neutral-50"
            >
              <ArrowLeft size={16} />
            </Link>
            <div>
              <p className="text-xs text-neutral-500">Campaigns / Detail</p>
              <p className="text-sm font-medium">{campaignData.name}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-neutral-200 bg-white px-3 text-xs font-medium text-neutral-700 hover:bg-neutral-50">
              <Edit3 size={14} />
              Edit Strategy
            </button>
            <button className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-neutral-950 px-3.5 text-xs font-medium text-white hover:bg-neutral-800">
              <RefreshCw size={14} />
              Regenerate Content
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="mx-auto max-w-[1450px] px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
          {/* Back button mobile */}
          <div className="mb-4 md:hidden">
            <Link
              href="/campaigns"
              className="inline-flex items-center gap-1.5 text-xs font-medium text-neutral-600"
            >
              <ArrowLeft size={14} />
              Back to Campaigns
            </Link>
          </div>

          {/* 1. Campaign Header */}
          <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
            <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <div className="flex flex-wrap items-center gap-3">
                  <h1 className="text-2xl font-bold tracking-tight sm:text-3xl text-neutral-950">
                    {campaignData.name}
                  </h1>
                  <span
                    className={`rounded-full px-3 py-1 text-xs font-semibold ${
                      isRunning
                        ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                        : "bg-neutral-100 text-neutral-600"
                    }`}
                  >
                    {isRunning ? "● Running" : "⏸ Paused"}
                  </span>
                </div>
                <p className="mt-2 max-w-3xl text-sm text-neutral-500">
                  {campaignData.objective}
                </p>
                <div className="mt-4 flex flex-wrap items-center gap-4 text-xs text-neutral-500">
                  <span>📅 {campaignData.startDate} – {campaignData.endDate}</span>
                  <span>·</span>
                  <span>Platforms: {campaignData.platforms.join(", ")}</span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 border-t border-neutral-100 pt-4 lg:border-t-0 lg:pt-0">
                <button
                  onClick={() => setIsRunning(!isRunning)}
                  className="inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-neutral-200 bg-white px-4 text-sm font-semibold text-neutral-800 hover:bg-neutral-50"
                >
                  {isRunning ? <Pause size={16} /> : <Play size={16} />}
                  {isRunning ? "Pause Campaign" : "Resume Campaign"}
                </button>
              </div>
            </div>

            {/* Lifecycle Progress Bar */}
            <div className="mt-8 border-t border-neutral-100 pt-6">
              <p className="text-xs font-medium text-neutral-500 mb-3">Campaign Execution Pipeline</p>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
                {lifecycleSteps.map((step, idx) => (
                  <div
                    key={step.name}
                    className={`flex items-center gap-2 rounded-xl border p-2.5 text-xs font-medium ${
                      step.status === "completed"
                        ? "border-emerald-200 bg-emerald-50/50 text-emerald-800"
                        : step.status === "active"
                        ? "border-neutral-950 bg-neutral-950 text-white font-semibold"
                        : "border-neutral-200 bg-neutral-50 text-neutral-400"
                    }`}
                  >
                    {step.status === "completed" ? (
                      <CheckCircle2 size={15} className="shrink-0 text-emerald-600" />
                    ) : (
                      <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full border border-current text-[10px]">
                        {idx + 1}
                      </span>
                    )}
                    <span className="truncate">{step.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* 2. Overview Performance Cards */}
          <section className="mt-7 grid grid-cols-2 gap-4 lg:grid-cols-5">
            <StatCard label="Total Reach" value={campaignData.reach} change="+12.3%" icon={Eye} />
            <StatCard label="Engagement" value={campaignData.engagement} change="+1.8%" icon={Heart} />
            <StatCard label="Posts Published" value={campaignData.postsPublished} change="68%" icon={CalendarDays} />
            <StatCard label="Link Clicks" value={campaignData.clicks} change="+15.4%" icon={TrendingUp} />
            <StatCard label="Conversions" value={campaignData.conversions} change="+22.1%" icon={Zap} />
          </section>

          {/* 3. Main Content & AI Activity Grid */}
          <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-3">
            {/* Generated Content Column */}
            <div className="space-y-6 lg:col-span-2">
              <div className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-base font-semibold text-neutral-950">Campaign Posts & Content</h2>
                    <p className="text-xs text-neutral-500">AI-generated assets for this campaign</p>
                  </div>
                  <button className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-neutral-950 px-3.5 text-xs font-semibold text-white hover:bg-neutral-800">
                    <Plus size={14} />
                    New Post
                  </button>
                </div>

                <div className="mt-6 space-y-4">
                  {generatedPosts.map((post) => (
                    <div
                      key={post.id}
                      className="rounded-xl border border-neutral-200 bg-white p-4 transition hover:border-neutral-400"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="rounded-md bg-neutral-100 px-2 py-0.5 text-xs font-semibold text-neutral-900">
                              {post.platform}
                            </span>
                            <span className="text-xs text-neutral-500">{post.time}</span>
                            <span
                              className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                                post.status === "Scheduled"
                                  ? "bg-emerald-100 text-emerald-800"
                                  : post.status === "Requires Review"
                                  ? "bg-amber-100 text-amber-800"
                                  : "bg-neutral-100 text-neutral-600"
                              }`}
                            >
                              {post.status}
                            </span>
                          </div>
                          <h3 className="text-sm font-semibold text-neutral-950 mt-1">{post.title}</h3>
                        </div>

                        <button className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-100">
                          <MoreHorizontal size={16} />
                        </button>
                      </div>

                      <p className="mt-3 text-xs leading-5 text-neutral-600 line-clamp-2">
                        {post.copy}
                      </p>

                      <div className="mt-4 flex items-center justify-between border-t border-neutral-100 pt-3 text-xs">
                        <div className="flex items-center gap-4 text-neutral-500">
                          <span>❤️ {post.likes}</span>
                          <span>💬 {post.comments}</span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button className="rounded-lg border border-neutral-200 px-3 py-1 font-medium text-neutral-700 hover:bg-neutral-50">
                            Edit Copy
                          </button>
                          <button className="rounded-lg bg-neutral-950 px-3 py-1 font-medium text-white hover:bg-neutral-800">
                            Approve
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* AI Log & Platform Connections Column */}
            <div className="space-y-6">
              {/* AI Activity Log */}
              <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
                <div className="flex items-center gap-2">
                  <Sparkles size={18} className="text-neutral-950" />
                  <h2 className="text-base font-semibold text-neutral-950">AI Optimization Log</h2>
                </div>
                <p className="mt-1 text-xs text-neutral-500">Autonomous decisions & adjustments</p>

                <div className="mt-5 space-y-4">
                  {aiLogs.map((log) => (
                    <div key={log.title} className="rounded-xl bg-neutral-50 p-3.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-neutral-900">{log.title}</span>
                        <span className="text-[10px] text-neutral-400">{log.time}</span>
                      </div>
                      <p className="mt-1.5 text-xs text-neutral-600 leading-4">{log.description}</p>
                    </div>
                  ))}
                </div>
              </section>

              {/* Connected Platforms for Campaign */}
              <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
                <h2 className="text-base font-semibold text-neutral-950">Campaign Channels</h2>
                <p className="text-xs text-neutral-500">Connected social media accounts</p>

                <div className="mt-4 space-y-3">
                  <div className="flex items-center justify-between rounded-xl border border-neutral-100 p-3">
                    <div className="flex items-center gap-2.5">
                      <Linkedin size={18} className="text-blue-700" />
                      <span className="text-xs font-semibold text-neutral-900">LinkedIn Page</span>
                    </div>
                    <span className="text-[10px] font-semibold text-emerald-600">Connected</span>
                  </div>

                  <div className="flex items-center justify-between rounded-xl border border-neutral-100 p-3">
                    <div className="flex items-center gap-2.5">
                      <Instagram size={18} className="text-pink-600" />
                      <span className="text-xs font-semibold text-neutral-900">Instagram Business</span>
                    </div>
                    <span className="text-[10px] font-semibold text-emerald-600">Connected</span>
                  </div>

                  <div className="flex items-center justify-between rounded-xl border border-neutral-100 p-3">
                    <div className="flex items-center gap-2.5">
                      <Facebook size={18} className="text-blue-600" />
                      <span className="text-xs font-semibold text-neutral-900">Facebook Page</span>
                    </div>
                    <span className="text-[10px] font-semibold text-emerald-600">Connected</span>
                  </div>

                  <div className="flex items-center justify-between rounded-xl border border-neutral-100 p-3">
                    <div className="flex items-center gap-2.5">
                      <Store size={18} className="text-emerald-600" />
                      <span className="text-xs font-semibold text-neutral-900">Google Business (GMB)</span>
                    </div>
                    <span className="text-[10px] font-semibold text-emerald-600">Connected</span>
                  </div>
                </div>
              </section>

              {/* Danger Zone */}
              <section className="rounded-2xl border border-red-200 bg-red-50/40 p-5">
                <h3 className="text-xs font-bold uppercase tracking-wider text-red-700">End Campaign</h3>
                <p className="mt-1 text-xs text-red-600">Archive this campaign and stop all future post schedules.</p>
                <button className="mt-4 h-9 w-full rounded-xl bg-red-600 text-xs font-semibold text-white hover:bg-red-700">
                  Archive Campaign
                </button>
              </section>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function StatCard({
  label,
  value,
  change,
  icon: Icon,
}: {
  label: string;
  value: string;
  change: string;
  icon: any;
}) {
  return (
    <div className="rounded-2xl border border-neutral-200 bg-white p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <p className="text-xs text-neutral-500">{label}</p>
        <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-neutral-50 text-neutral-800">
          <Icon size={16} />
        </div>
      </div>
      <p className="mt-3 text-xl font-bold tracking-tight text-neutral-950 sm:text-2xl">{value}</p>
      <div className="mt-2 flex items-center gap-1 text-xs text-emerald-600">
        <TrendingUp size={13} />
        <span className="font-semibold">{change}</span>
      </div>
    </div>
  );
}
