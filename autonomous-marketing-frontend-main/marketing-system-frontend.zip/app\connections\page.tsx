"use client";

import { useState } from "react";
import {
  ArrowRight,
  Check,
  ChevronRight,
  Facebook,
  Instagram,
  Linkedin,
  Menu,
  MoreHorizontal,
  Plus,
  RefreshCw,
  Settings2,
  ShieldCheck,
  Sparkles,
  Store,
  Unplug,
} from "lucide-react";

import { DashboardSidebar } from "@/components/navigation/dashboard-sidebar";

type Platform = {
  name: string;
  description: string;
  connected: boolean;
  account?: string;
  status?: string;
};

const platforms: Platform[] = [
  {
    name: "Instagram",
    description: "Publish photos, reels, stories, and campaign content.",
    connected: true,
    account: "@yourbusiness",
    status: "Connected",
  },
  {
    name: "Facebook",
    description: "Publish posts and manage your Facebook business presence.",
    connected: true,
    account: "Your Business Page",
    status: "Connected",
  },
  {
    name: "LinkedIn",
    description: "Publish professional content to your company page.",
    connected: true,
    account: "Your Company",
    status: "Connected",
  },
  {
    name: "Google Business (GMB)",
    description: "Publish local updates, offers, and manage Google Search & Maps profile.",
    connected: false,
  },
];

export default function ConnectionsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white text-neutral-950">
      <DashboardSidebar
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <main className="min-h-screen md:pl-[230px]">
        {/* Mobile Header */}
        <header className="sticky top-0 z-40 flex h-16 items-center justify-between border-b border-neutral-200 bg-white px-4 md:hidden">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              aria-label="Open menu"
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-50"
            >
              <Menu size={19} />
            </button>
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-full bg-neutral-950 text-white">
                <Sparkles size={14} />
              </div>
              <span className="text-sm font-semibold">Marketing System</span>
            </div>
          </div>
        </header>

        {/* Desktop Header */}
        <div className="hidden h-16 items-center justify-between border-b border-neutral-200 px-7 md:flex">
          <div>
            <p className="text-xs text-neutral-500">Workspace</p>
            <p className="text-sm font-medium">Your business workspace</p>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="h-2 w-2 rounded-full bg-emerald-500" />
            <span className="font-medium text-neutral-700">3 of 4 platforms connected</span>
          </div>
        </div>

        {/* Content */}
        <div className="mx-auto w-full max-w-[1450px] px-4 py-6 sm:px-6 lg:px-8">
          {/* Header */}
          <section className="mb-8 flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <p className="mb-1 text-sm text-neutral-500">Workspace</p>
              <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
                Connections
              </h1>
              <p className="mt-1 max-w-2xl text-sm text-neutral-500 sm:text-base">
                Connect your social platforms so your marketing system can
                create, schedule, and publish content automatically.
              </p>
            </div>

            <button className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-neutral-950 px-5 text-sm font-medium text-white transition hover:bg-neutral-800">
              <Plus className="h-4 w-4" />
              Connect platform
            </button>
          </section>

          {/* Connection status */}
          <section className="mb-6 rounded-2xl border border-neutral-200 bg-white p-5 sm:p-6 shadow-sm">
            <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
              <div className="flex gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-neutral-200">
                  <ShieldCheck className="h-5 w-5" />
                </div>

                <div>
                  <h2 className="font-semibold text-neutral-950">
                    Your accounts are secure
                  </h2>
                  <p className="mt-1 text-sm text-neutral-500">
                    Connections use secure authorization. Your passwords are
                    never stored by the marketing system.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-sm">
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                <span className="font-medium text-neutral-700">3 of 4 platforms connected</span>
              </div>
            </div>
          </section>

          {/* Platform cards */}
          <section className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {platforms.map((platform) => (
              <PlatformCard
                key={platform.name}
                platform={platform}
              />
            ))}
          </section>

          {/* AI publishing section */}
          <section className="mt-6 rounded-2xl border border-neutral-200 bg-white p-5 sm:p-6 shadow-sm">
            <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
              <div className="flex gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-neutral-200 bg-neutral-950 text-white">
                  <Sparkles className="h-5 w-5" />
                </div>

                <div>
                  <h2 className="font-semibold text-neutral-950">
                    Autonomous publishing
                  </h2>

                  <p className="mt-1 max-w-2xl text-sm leading-6 text-neutral-500">
                    Once your platforms are connected, the system can use your
                    campaign strategy to generate content, schedule posts, and
                    publish them according to your campaign settings.
                  </p>
                </div>
              </div>

              <button className="inline-flex h-10 shrink-0 items-center justify-center gap-2 rounded-xl border border-neutral-200 px-4 text-sm font-medium transition hover:bg-neutral-50">
                Publishing settings
                <Settings2 className="h-4 w-4" />
              </button>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}

function PlatformCard({
  platform,
}: {
  platform: Platform;
}) {
  const Icon = getPlatformIcon(platform.name);

  return (
    <article className="rounded-2xl border border-neutral-200 bg-white p-5 transition hover:shadow-sm sm:p-6">
      {/* Card header */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex min-w-0 gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-neutral-200 bg-white">
            <Icon className="h-6 w-6" />
          </div>

          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-semibold text-neutral-950">
                {platform.name}
              </h2>

              {platform.connected ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 border border-emerald-200 px-2 py-0.5 text-xs font-semibold text-emerald-700">
                  <Check className="h-3 w-3" />
                  Connected
                </span>
              ) : (
                <span className="rounded-full border border-neutral-200 px-2 py-0.5 text-xs text-neutral-500">
                  Not connected
                </span>
              )}
            </div>

            <p className="mt-1 text-sm leading-5 text-neutral-500">
              {platform.description}
            </p>
          </div>
        </div>

        <button
          aria-label={`More options for ${platform.name}`}
          className="shrink-0 rounded-lg p-2 transition hover:bg-neutral-100"
        >
          <MoreHorizontal className="h-5 w-5 text-neutral-500" />
        </button>
      </div>

      {/* Connected account */}
      {platform.connected ? (
        <div className="mt-6 rounded-xl bg-neutral-50 p-4">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-xs text-neutral-500">
                Connected account
              </p>

              <p className="mt-1 text-sm font-medium text-neutral-900">
                {platform.account}
              </p>
            </div>

            <div className="flex gap-2">
              <button className="inline-flex h-9 items-center gap-2 rounded-lg border border-neutral-200 bg-white px-3 text-xs font-medium text-neutral-700 hover:bg-neutral-50">
                <RefreshCw className="h-3.5 w-3.5" />
                Refresh
              </button>

              <button className="inline-flex h-9 items-center gap-2 rounded-lg border border-neutral-200 bg-white px-3 text-xs font-medium text-neutral-700 hover:bg-neutral-50">
                <Unplug className="h-3.5 w-3.5" />
                Disconnect
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="mt-6">
          <button className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-xl bg-neutral-950 px-4 text-sm font-medium text-white transition hover:bg-neutral-800 sm:w-auto">
            Connect {platform.name}
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Capabilities */}
      {platform.connected && (
        <div className="mt-5 flex flex-wrap gap-2">
          <Capability label="Publishing" />
          <Capability label="Scheduling" />
          <Capability label="Analytics" />
        </div>
      )}
    </article>
  );
}

function Capability({
  label,
}: {
  label: string;
}) {
  return (
    <span className="rounded-md border border-neutral-200 px-2.5 py-1 text-xs text-neutral-500">
      {label}
    </span>
  );
}

function getPlatformIcon(name: string) {
  switch (name) {
    case "Instagram":
      return Instagram;
    case "Facebook":
      return Facebook;
    case "LinkedIn":
      return Linkedin;
    case "Google Business (GMB)":
      return Store;
    default:
      return ChevronRight;
  }
}
