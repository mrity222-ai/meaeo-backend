"use client";

import { useState } from "react";
import Link from "next/link";
import {
  ArrowUpRight,
  ChevronRight,
  CirclePause,
  CirclePlay,
  Ellipsis,
  Menu,
  Plus,
  Search,
  Sparkles,
  Target,
  TrendingUp,
} from "lucide-react";

import { DashboardSidebar } from "@/components/navigation/dashboard-sidebar";

const campaigns = [
  {
    name: "September Growth Campaign",
    objective: "Increase brand awareness and reach",
    status: "Running",
    progress: 68,
    posts: "17 / 25 posts",
    platforms: ["Instagram", "LinkedIn"],
    reach: "12.4K",
    engagement: "8.6%",
    date: "Sep 1 – Sep 30",
  },
  {
    name: "Product Awareness",
    objective: "Drive awareness for new product launch",
    status: "Paused",
    progress: 42,
    posts: "8 / 19 posts",
    platforms: ["Instagram", "Facebook"],
    reach: "7.2K",
    engagement: "6.4%",
    date: "Sep 5 – Sep 25",
  },
  {
    name: "Founder Brand Campaign",
    objective: "Build authority and audience trust",
    status: "Draft",
    progress: 12,
    posts: "3 / 24 posts",
    platforms: ["LinkedIn"],
    reach: "—",
    engagement: "—",
    date: "Sep 10 – Oct 10",
  },
];

export default function CampaignsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white text-[#09090b]">
      <DashboardSidebar
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <main className="min-h-screen md:pl-[230px]">
        {/* Mobile Header */}
        <header className="sticky top-0 z-40 flex h-16 items-center justify-between border-b border-[#e4e4e7] bg-white px-4 md:hidden">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              aria-label="Open menu"
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-[#e4e4e7] text-neutral-700 hover:bg-[#fafafa]"
            >
              <Menu size={19} />
            </button>
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#09090b] text-white">
                <Sparkles size={14} />
              </div>
              <span className="text-sm font-semibold">Marketing System</span>
            </div>
          </div>
        </header>

        {/* Desktop Top Bar */}
        <div className="hidden h-16 items-center justify-between border-b border-[#e4e4e7] px-7 md:flex">
          <div>
            <p className="text-xs text-[#71717a]">Workspace</p>
            <p className="text-sm font-medium">Your business workspace</p>
          </div>

          <div className="flex items-center gap-3">
            <button className="rounded-lg border border-[#e4e4e7] p-2.5 hover:bg-[#fafafa]">
              <Search size={17} />
            </button>
            <div className="h-8 w-8 rounded-full bg-[#09090b]" />
          </div>
        </div>

        {/* Page Content */}
        <div className="mx-auto max-w-[1450px] px-4 py-6 sm:px-6 lg:px-7 lg:py-8">
          {/* Heading */}
          <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-sm text-[#71717a]">Workspace</p>
              <h1 className="mt-1 text-2xl font-semibold tracking-tight sm:text-3xl">
                Campaigns
              </h1>
              <p className="mt-2 max-w-xl text-sm text-[#71717a]">
                Create, manage, and monitor your autonomous marketing campaigns.
              </p>
            </div>

            <button className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-[#09090b] px-4 text-sm font-medium text-white transition hover:bg-[#27272a]">
              <Plus size={17} />
              Create campaign
            </button>
          </div>

          {/* Stats */}
          <div className="mt-7 grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
            <StatCard
              label="Active campaigns"
              value="2"
              change="+1 this month"
            />
            <StatCard
              label="Total reach"
              value="24.8K"
              change="+18.4%"
            />
            <StatCard
              label="Engagement"
              value="8.6%"
              change="+2.1%"
            />
            <StatCard
              label="Posts published"
              value="42"
              change="+12 this month"
            />
          </div>

          {/* Filters */}
          <div className="mt-7 flex flex-col gap-3 border-b border-[#e4e4e7] pb-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex gap-1 overflow-x-auto">
              <FilterButton active label="All campaigns" />
              <FilterButton label="Running" />
              <FilterButton label="Paused" />
              <FilterButton label="Drafts" />
            </div>

            <button className="flex h-9 shrink-0 items-center gap-2 rounded-lg border border-[#e4e4e7] px-3 text-sm text-[#52525b]">
              <Search size={15} />
              <span className="hidden sm:inline">Search campaigns</span>
            </button>
          </div>

          {/* Campaign List */}
          <div className="mt-5 space-y-4">
            {campaigns.map((campaign) => (
              <CampaignCard
                key={campaign.name}
                campaign={campaign}
              />
            ))}
          </div>

          {/* AI Banner */}
          <section className="mt-7 rounded-xl border border-[#e4e4e7] bg-[#fafafa] p-5 sm:p-6">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex gap-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-[#09090b] text-white">
                  <Sparkles size={18} />
                </div>

                <div>
                  <h2 className="text-sm font-semibold">
                    Let AI build your next campaign
                  </h2>

                  <p className="mt-1 max-w-xl text-sm text-[#71717a]">
                    Your marketing system can create the strategy, content,
                    schedule, and optimization plan automatically.
                  </p>
                </div>
              </div>

              <button className="inline-flex h-9 shrink-0 items-center justify-center gap-2 rounded-lg border border-[#d4d4d8] bg-white px-3 text-sm font-medium">
                Build with AI
                <ArrowUpRight size={15} />
              </button>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}

function StatCard({
  label,
  value,
  change,
}: {
  label: string;
  value: string;
  change: string;
}) {
  return (
    <div className="rounded-xl border border-[#e4e4e7] p-4 sm:p-5">
      <p className="text-xs text-[#71717a] sm:text-sm">{label}</p>
      <p className="mt-1 text-xl font-semibold tracking-tight sm:text-2xl">
        {value}
      </p>
      <div className="mt-2 flex items-center gap-1 text-xs text-emerald-600">
        <TrendingUp size={13} />
        {change}
      </div>
    </div>
  );
}

function FilterButton({
  label,
  active = false,
}: {
  label: string;
  active?: boolean;
}) {
  return (
    <button
      className={`whitespace-nowrap rounded-lg px-3 py-2 text-sm ${
        active
          ? "bg-[#09090b] font-medium text-white"
          : "text-[#71717a] hover:bg-[#f4f4f5]"
      }`}
    >
      {label}
    </button>
  );
}

function CampaignCard({
  campaign,
}: {
  campaign: (typeof campaigns)[number];
}) {
  const isRunning = campaign.status === "Running";
  const isPaused = campaign.status === "Paused";

  return (
    <article className="rounded-xl border border-[#e4e4e7] bg-white p-4 transition hover:border-[#a1a1aa] sm:p-5">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-base font-semibold sm:text-lg">
              {campaign.name}
            </h2>

            <span
              className={`rounded-full px-2 py-1 text-[11px] font-medium ${
                isRunning
                  ? "bg-[#f4f4f5] text-[#18181b]"
                  : isPaused
                    ? "bg-[#fafafa] text-[#71717a]"
                    : "bg-[#fafafa] text-[#71717a]"
              }`}
            >
              {campaign.status}
            </span>
          </div>

          <p className="mt-1 text-sm text-[#71717a]">
            {campaign.objective}
          </p>
        </div>

        <button
          aria-label={`More options for ${campaign.name}`}
          className="self-end rounded-lg p-2 text-[#71717a] hover:bg-[#f4f4f5] sm:self-auto"
        >
          <Ellipsis size={19} />
        </button>
      </div>

      <div className="mt-5">
        <div className="mb-2 flex items-center justify-between text-xs">
          <span className="text-[#71717a]">
            {campaign.posts}
          </span>

          <span className="font-medium">
            {campaign.progress}%
          </span>
        </div>

        <div className="h-2 overflow-hidden rounded-full bg-[#f4f4f5]">
          <div
            className="h-full rounded-full bg-[#09090b] transition-all"
            style={{ width: `${campaign.progress}%` }}
          />
        </div>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-4 border-t border-[#f0f0f1] pt-4 sm:grid-cols-4">
        <Detail label="Reach" value={campaign.reach} />
        <Detail label="Engagement" value={campaign.engagement} />
        <Detail label="Platforms" value={campaign.platforms.join(" · ")} />
        <Detail label="Schedule" value={campaign.date} />
      </div>

      <div className="mt-5 flex flex-col gap-2 border-t border-[#f0f0f1] pt-4 sm:flex-row sm:items-center sm:justify-between">
        <button className="inline-flex items-center justify-center gap-2 rounded-lg border border-[#e4e4e7] px-3 py-2 text-sm font-medium hover:bg-[#fafafa]">
          View campaign
          <ChevronRight size={15} />
        </button>

        {isRunning ? (
          <button className="inline-flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm text-[#71717a] hover:bg-[#f4f4f5]">
            <CirclePause size={15} />
            Pause
          </button>
        ) : isPaused ? (
          <button className="inline-flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm font-medium hover:bg-[#f4f4f5]">
            <CirclePlay size={15} />
            Resume
          </button>
        ) : (
          <button className="inline-flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm font-medium hover:bg-[#f4f4f5]">
            <CirclePlay size={15} />
            Start campaign
          </button>
        )}
      </div>
    </article>
  );
}

function Detail({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="min-w-0">
      <p className="text-xs text-[#a1a1aa]">{label}</p>
      <p className="mt-1 truncate text-sm font-medium">{value}</p>
    </div>
  );
}
