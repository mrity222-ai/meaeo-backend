export interface OnboardingData {
  businessName: string;
  industry: string;
  website: string;
  description: string;

  targetAudience: string;
  targetLocation: string;

  goals: string[];
  platforms: string[];

  catalogueFile: File | null;
}
