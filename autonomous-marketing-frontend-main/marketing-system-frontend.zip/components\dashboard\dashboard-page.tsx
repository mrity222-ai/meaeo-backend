"use client";

import Link from "next/link";
import { useState } from "react";
import {
  ArrowUpRight,
  Bell,
  CalendarDays,
  Eye,
  Heart,
  Link2,
  Menu,
  MessageCircle,
  Play,
  Plus,
  Sparkles,
  Users,
  BarChart3,
  Pause,
  Clock3,
  Megaphone,
} from "lucide-react";

import { DashboardSidebar } from "@/components/navigation/dashboard-sidebar";

const stats = [
  {
    label: "Reach",
    value: "24.8K",
    change: "+18.4%",
    description: "vs. last 30 days",
    icon: Eye,
  },
  {
    label: "Engagement",
    value: "8.6%",
    change: "+2.1%",
    description: "vs. last 30 days",
    icon: Heart,
  },
  {
    label: "Followers",
    value: "4,821",
    change: "+9.7%",
    description: "vs. last 30 days",
    icon: Users,
  },
  {
    label: "Posts published",
    value: "42",
    change: "+12",
    description: "this month",
    icon: BarChart3,
  },
];

const campaigns = [
  {
    name: "September Growth Campaign",
    status: "Running",
    posts: "17 / 25 posts",
    progress: 68,
    icon: Play,
  },
  {
    name: "Product Awareness",
    status: "Paused",
    posts: "8 / 19 posts",
    progress: 42,
    icon: Pause,
  },
];

const upcomingPosts = [
  {
    initials: "In",
    platform: "Instagram",
    title: "5 ways to improve your social media presence",
    time: "Today · 6:30 PM",
  },
  {
    initials: "Li",
    platform: "LinkedIn",
    title: "What businesses should know about AI marketing",
    time: "Tomorrow · 10:00 AM",
  },
  {
    initials: "Fb",
    platform: "Facebook",
    title: "Behind the scenes: our latest campaign",
    time: "Tomorrow · 4:00 PM",
  },
];

const aiActivity = [
  {
    title: "Campaign content generated",
    description: "6 new posts created for September Growth Campaign.",
  },
  {
    title: "Best performing content detected",
    description:
      "Engagement increased 24% compared with the previous period.",
  },
  {
    title: "Next optimization scheduled",
    description: "The system will review campaign performance automatically.",
  },
];

export function DashboardPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white text-neutral-950">
      <DashboardSidebar
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <main className="min-h-screen md:pl-[230px]">
        {/* Header */}
        <header className="border-b border-neutral-200">
          <div className="flex min-h-[76px] items-center justify-between gap-4 px-5 py-4 sm:px-7 lg:px-8">
            <div className="flex min-w-0 items-center gap-3">
              <button
                onClick={() => setSidebarOpen(true)}
                aria-label="Open navigation"
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-neutral-200 text-neutral-700 hover:bg-neutral-50 md:hidden"
              >
                <Menu size={19} />
              </button>

              <div className="min-w-0">
                <p className="text-xs text-neutral-500">
                  Wednesday, September 9
                </p>

                <h1 className="mt-0.5 truncate text-xl font-semibold tracking-[-0.025em] sm:text-[22px]">
                  Good morning 👋
                </h1>

                <p className="mt-0.5 hidden text-sm text-neutral-500 sm:block">
                  Here&apos;s what your marketing system is working on.
                </p>
              </div>
            </div>

            <div className="flex shrink-0 items-center gap-2">
              <button
                aria-label="Notifications"
                className="flex h-10 w-10 items-center justify-center rounded-xl border border-neutral-200 text-neutral-700 hover:bg-neutral-50"
              >
                <Bell size={18} strokeWidth={1.8} />
              </button>

              <div className="hidden h-10 min-w-[145px] rounded-xl bg-neutral-950 sm:block" />
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="mx-auto max-w-[1450px] px-4 py-6 sm:px-6 lg:px-8 lg:py-7">
          {/* Stats */}
          <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((stat) => {
              const Icon = stat.icon;

              return (
                <div
                  key={stat.label}
                  className="rounded-2xl border border-neutral-200 bg-white p-5 shadow-[0_1px_2px_rgba(0,0,0,0.03)]"
                >
                  <div className="flex items-start justify-between gap-3">
                    <p className="text-sm text-neutral-500">{stat.label}</p>

                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-neutral-200 bg-neutral-50">
                      <Icon size={17} strokeWidth={1.7} />
                    </div>
                  </div>

                  <p className="mt-1 text-[28px] font-semibold tracking-[-0.04em] sm:text-[30px]">
                    {stat.value}
                  </p>

                  <p className="mt-3 flex items-center gap-1 text-xs">
                    <span className="font-medium text-emerald-600">
                      ↗ {stat.change}
                    </span>
                    <span className="text-neutral-500">
                      {stat.description}
                    </span>
                  </p>
                </div>
              );
            })}
          </section>

          {/* Campaigns + quick actions */}
          <section className="mt-5 grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_288px]">
            {/* Active campaigns */}
            <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white">
              <div className="flex items-center justify-between gap-4 border-b border-neutral-200 px-5 py-5">
                <div>
                  <h2 className="text-[15px] font-semibold">
                    Active campaigns
                  </h2>
                  <p className="mt-1 text-xs text-neutral-500">
                    Current campaign activity
                  </p>
                </div>

                <Link
                  href="/campaigns"
                  className="flex shrink-0 items-center gap-1 text-sm font-medium text-neutral-950 hover:underline"
                >
                  View all
                  <ArrowUpRight size={15} />
                </Link>
              </div>

              <div>
                {campaigns.map((campaign, index) => {
                  const StatusIcon = campaign.icon;

                  return (
                    <div
                      key={campaign.name}
                      className={[
                        "px-5 py-5",
                        index !== campaigns.length - 1
                          ? "border-b border-neutral-200"
                          : "",
                      ].join(" ")}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium">
                            {campaign.name}
                          </p>

                          <div className="mt-1.5 flex items-center gap-2 text-xs text-neutral-500">
                            <StatusIcon size={12} strokeWidth={1.8} />
                            <span>{campaign.status}</span>
                            <span>·</span>
                            <span>{campaign.posts}</span>
                          </div>
                        </div>

                        <span className="shrink-0 text-xs font-semibold">
                          {campaign.progress}%
                        </span>
                      </div>

                      <div className="mt-4 h-2 overflow-hidden rounded-full bg-neutral-100">
                        <div
                          className="h-full rounded-full bg-neutral-950 transition-all"
                          style={{ width: `${campaign.progress}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick actions */}
            <div className="rounded-2xl border border-neutral-200 bg-white p-5">
              <div className="flex items-center gap-2">
                <Sparkles size={17} />
                <h2 className="text-[15px] font-semibold">Quick actions</h2>
              </div>

              <div className="mt-5 space-y-2">
                <QuickAction
                  href="/campaigns"
                  icon={<MegaphoneIcon />}
                  title="Create campaign"
                  description="Let AI build your campaign strategy"
                />

                <QuickAction
                  href="/connections"
                  icon={<Link2 size={17} strokeWidth={1.7} />}
                  title="Connect platform"
                  description="Connect your social media accounts"
                />

                <QuickAction
                  href="/calendar"
                  icon={<CalendarDays size={17} strokeWidth={1.7} />}
                  title="View calendar"
                  description="Review your upcoming content"
                />
              </div>
            </div>
          </section>

          {/* Upcoming + AI */}
          <section className="mt-5 grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
            {/* Upcoming posts */}
            <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white">
              <div className="border-b border-neutral-200 px-5 py-5">
                <div className="flex items-center gap-2">
                  <CalendarDays size={17} />
                  <h2 className="text-[15px] font-semibold">
                    Upcoming posts
                  </h2>
                </div>

                <p className="mt-1 text-xs text-neutral-500">
                  Content scheduled by your marketing system
                </p>
              </div>

              <div>
                {upcomingPosts.map((post, index) => (
                  <div
                    key={post.title}
                    className={[
                      "flex items-center gap-4 px-5 py-4",
                      index !== upcomingPosts.length - 1
                        ? "border-b border-neutral-200"
                        : "",
                    ].join(" ")}
                  >
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-neutral-100 text-xs font-medium">
                      {post.initials}
                    </div>

                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">
                        {post.title}
                      </p>

                      <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-neutral-500">
                        <span>{post.platform}</span>
                        <span className="flex items-center gap-1">
                          <Clock3 size={11} />
                          {post.time}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* AI activity */}
            <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white">
              <div className="border-b border-neutral-200 px-5 py-5">
                <div className="flex items-center gap-2">
                  <MessageCircle size={17} />
                  <h2 className="text-[15px] font-semibold">AI activity</h2>
                </div>

                <p className="mt-1 text-xs text-neutral-500">
                  What your autonomous marketing system has been doing.
                </p>
              </div>

              <div className="space-y-3 p-4">
                {aiActivity.map((activity) => (
                  <div
                    key={activity.title}
                    className="rounded-xl bg-neutral-50 p-4"
                  >
                    <p className="text-sm font-medium">{activity.title}</p>
                    <p className="mt-1 text-xs leading-5 text-neutral-500">
                      {activity.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}

function QuickAction({
  href,
  icon,
  title,
  description,
}: {
  href: string;
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <Link
      href={href}
      className="flex items-center gap-3 rounded-xl p-2.5 transition-colors hover:bg-neutral-50"
    >
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-neutral-200 bg-white">
        {icon}
      </div>

      <div className="min-w-0">
        <p className="text-sm font-medium">{title}</p>
        <p className="truncate text-[11px] text-neutral-500">
          {description}
        </p>
      </div>
    </Link>
  );
}

function MegaphoneIcon() {
  return <Megaphone size={17} strokeWidth={1.7} />;
}
