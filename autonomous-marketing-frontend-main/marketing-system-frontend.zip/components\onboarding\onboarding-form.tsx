"use client";

import {
  ArrowLeft,
  ArrowRight,
  Check,
  Globe,
  Target,
  Upload,
  Users,
  Zap,
  RotateCcw,
  Sparkles,
} from "lucide-react";
import { useState } from "react";
import Link from "next/link";

import type { OnboardingData } from "@/types/onboarding";

const steps = [
  {
    number: 1,
    title: "Your business",
    description: "Tell us about your business.",
    icon: Globe,
  },
  {
    number: 2,
    title: "Your audience",
    description: "Who are you trying to reach?",
    icon: Users,
  },
  {
    number: 3,
    title: "Your goals",
    description: "What do you want your marketing to achieve?",
    icon: Target,
  },
  {
    number: 4,
    title: "Your brand",
    description: "Give the AI the information it needs.",
    icon: Zap,
  },
];

const goalOptions = [
  "Increase sales",
  "Generate leads",
  "Build brand awareness",
  "Grow social media",
  "Drive website traffic",
  "Launch a new product",
];

const platformOptions = [
  "Instagram",
  "Facebook",
  "LinkedIn",
  "Google Business",
];

// Pre-filled sample data
const sampleDummyData: OnboardingData = {
  businessName: "Beyond Stories Marketing",
  industry: "E-Commerce & Retail",
  website: "https://beyondstories.com",
  description:
    "Autonomous AI-powered marketing system helping retail businesses and local stores grow their sales, reach, and brand awareness across platforms.",
  targetAudience:
    "Small business owners, local shop owners, boutique brands, and marketing agencies aged 25-50 looking for automated social media growth.",
  targetLocation: "India, Delhi NCR, Mumbai, Bangalore",
  goals: ["Increase sales", "Generate leads", "Build brand awareness", "Grow social media"],
  platforms: ["Instagram", "Facebook", "LinkedIn", "Google Business"],
  catalogueFile: null,
};

const emptyData: OnboardingData = {
  businessName: "",
  industry: "",
  website: "",
  description: "",
  targetAudience: "",
  targetLocation: "",
  goals: [],
  platforms: [],
  catalogueFile: null,
};

export function OnboardingForm() {
  const [currentStep, setCurrentStep] = useState(1);
  const [data, setData] = useState<OnboardingData>(sampleDummyData);

  const updateField = <K extends keyof OnboardingData>(
    field: K,
    value: OnboardingData[K],
  ) => {
    setData((previous) => ({
      ...previous,
      [field]: value,
    }));
  };

  const toggleArrayValue = (
    field: "goals" | "platforms",
    value: string,
  ) => {
    setData((previous) => {
      const current = previous[field];

      return {
        ...previous,
        [field]: current.includes(value)
          ? current.filter((item) => item !== value)
          : [...current, value],
      };
    });
  };

  const nextStep = () => {
    if (currentStep < steps.length) {
      setCurrentStep((step) => step + 1);
    }
  };

  const previousStep = () => {
    if (currentStep > 1) {
      setCurrentStep((step) => step - 1);
    }
  };

  const completeOnboarding = () => {
    console.log("Completed Onboarding data:", data);
    alert(`🎉 Setup Complete!\n\nBusiness: ${data.businessName}\nIndustry: ${data.industry}\nGoals: ${data.goals.join(", ")}\nPlatforms: ${data.platforms.join(", ")}`);
  };

  return (
    <div className="w-full max-w-4xl font-sans">
      
      {/* Top Header Logo */}
      <div className="mb-8 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2.5 font-bold text-zinc-900">
          <img
            src="/logo/app logo.png"
            alt="Logo"
            className="h-8 w-8 object-contain"
          />
          <span className="text-xl tracking-tight">Marketing System</span>
        </Link>

        {/* Preset controls */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setData(sampleDummyData)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-purple-200 bg-purple-50 px-3 py-1.5 text-xs font-semibold text-purple-700 transition hover:bg-purple-100"
          >
            <Sparkles className="h-3.5 w-3.5" />
            Load Sample Data
          </button>

          <button
            type="button"
            onClick={() => setData(emptyData)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-200 bg-white px-3 py-1.5 text-xs font-medium text-zinc-600 transition hover:bg-zinc-50"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Reset
          </button>
        </div>
      </div>

      {/* Progress Steps Header */}
      <div className="mb-10">
        <div className="flex items-center justify-between">
          {steps.map((step, index) => {
            const Icon = step.icon;
            const completed = currentStep > step.number;
            const active = currentStep === step.number;

            return (
              <div key={step.number} className="flex flex-1 items-center">
                <div className="flex flex-col items-center">
                  <button
                    type="button"
                    onClick={() => setCurrentStep(step.number)}
                    className={
                      completed
                        ? "flex h-11 w-11 items-center justify-center rounded-full border border-purple-600 bg-purple-600 text-white transition hover:scale-105"
                        : active
                        ? "flex h-11 w-11 items-center justify-center rounded-full border-2 border-purple-600 bg-purple-600 text-white shadow-md shadow-purple-200 transition hover:scale-105"
                        : "flex h-11 w-11 items-center justify-center rounded-full border border-zinc-200 bg-white text-zinc-400 transition hover:border-zinc-400"
                    }
                  >
                    {completed ? (
                      <Check className="h-5 w-5 stroke-[2.5]" />
                    ) : (
                      <Icon className="h-5 w-5" />
                    )}
                  </button>

                  <span
                    onClick={() => setCurrentStep(step.number)}
                    className={
                      active || completed
                        ? "mt-2 hidden cursor-pointer text-xs font-bold text-zinc-900 sm:block"
                        : "mt-2 hidden cursor-pointer text-xs font-medium text-zinc-400 sm:block"
                    }
                  >
                    {step.title}
                  </span>
                </div>

                {index < steps.length - 1 && (
                  <div
                    className={
                      currentStep > step.number
                        ? "mx-3 h-0.5 flex-1 bg-purple-600"
                        : "mx-3 h-0.5 flex-1 bg-zinc-200"
                    }
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Form Card */}
      <div className="rounded-3xl border border-purple-100/80 bg-white p-6 shadow-xl shadow-purple-500/5 sm:p-10">
        
        {/* Step Heading */}
        <div className="mb-8 border-b border-zinc-100 pb-6">
          <p className="mb-1.5 text-xs font-bold uppercase tracking-wider text-purple-600">
            Step {currentStep} of {steps.length}
          </p>

          <h1 className="text-2xl font-extrabold tracking-tight text-zinc-900 sm:text-3xl">
            {steps[currentStep - 1].title}
          </h1>

          <p className="mt-1.5 text-sm text-zinc-500">
            {steps[currentStep - 1].description}
          </p>
        </div>

        {/* STEP 1 */}
        {currentStep === 1 && (
          <div className="space-y-6">
            <div>
              <label className="mb-2 block text-sm font-semibold text-zinc-900">
                Business name
              </label>
              <input
                value={data.businessName}
                onChange={(event) =>
                  updateField("businessName", event.target.value)
                }
                placeholder="e.g. Beyond Stories"
                className="h-12 w-full rounded-xl border border-zinc-200 bg-white px-4 text-sm text-zinc-900 outline-none transition focus:border-purple-600 focus:ring-2 focus:ring-purple-100 placeholder:text-zinc-400"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-semibold text-zinc-900">
                Industry
              </label>
              <input
                value={data.industry}
                onChange={(event) =>
                  updateField("industry", event.target.value)
                }
                placeholder="e.g. Fashion, restaurant, SaaS..."
                className="h-12 w-full rounded-xl border border-zinc-200 bg-white px-4 text-sm text-zinc-900 outline-none transition focus:border-purple-600 focus:ring-2 focus:ring-purple-100 placeholder:text-zinc-400"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-semibold text-zinc-900">
                Website
              </label>
              <input
                type="url"
                value={data.website}
                onChange={(event) =>
                  updateField("website", event.target.value)
                }
                placeholder="https://example.com"
                className="h-12 w-full rounded-xl border border-zinc-200 bg-white px-4 text-sm text-zinc-900 outline-none transition focus:border-purple-600 focus:ring-2 focus:ring-purple-100 placeholder:text-zinc-400"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-semibold text-zinc-900">
                Tell us about your business
              </label>
              <textarea
                value={data.description}
                onChange={(event) =>
                  updateField("description", event.target.value)
                }
                placeholder="What does your business do? What products or services do you offer?"
                rows={5}
                className="w-full resize-none rounded-xl border border-zinc-200 bg-white p-4 text-sm text-zinc-900 outline-none transition focus:border-purple-600 focus:ring-2 focus:ring-purple-100 placeholder:text-zinc-400"
              />
            </div>
          </div>
        )}

        {/* STEP 2 */}
        {currentStep === 2 && (
          <div className="space-y-6">
            <div>
              <label className="mb-2 block text-sm font-semibold text-zinc-900">
                Who is your target audience?
              </label>
              <textarea
                value={data.targetAudience}
                onChange={(event) =>
                  updateField("targetAudience", event.target.value)
                }
                placeholder="Describe your ideal customer, their interests, age range, profession, needs, etc."
                rows={6}
                className="w-full resize-none rounded-xl border border-zinc-200 bg-white p-4 text-sm text-zinc-900 outline-none transition focus:border-purple-600 focus:ring-2 focus:ring-purple-100 placeholder:text-zinc-400"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-semibold text-zinc-900">
                Target location
              </label>
              <input
                value={data.targetLocation}
                onChange={(event) =>
                  updateField("targetLocation", event.target.value)
                }
                placeholder="e.g. India, Delhi NCR, United States..."
                className="h-12 w-full rounded-xl border border-zinc-200 bg-white px-4 text-sm text-zinc-900 outline-none transition focus:border-purple-600 focus:ring-2 focus:ring-purple-100 placeholder:text-zinc-400"
              />
            </div>
          </div>
        )}

        {/* STEP 3 */}
        {currentStep === 3 && (
          <div className="space-y-8">
            <div>
              <h2 className="mb-3 text-sm font-semibold text-zinc-900">
                What are your marketing goals?
              </h2>

              <div className="grid gap-3 sm:grid-cols-2">
                {goalOptions.map((goal) => {
                  const selected = data.goals.includes(goal);

                  return (
                    <button
                      type="button"
                      key={goal}
                      onClick={() => toggleArrayValue("goals", goal)}
                      className={
                        selected
                          ? "rounded-2xl border-2 border-purple-600 bg-purple-600 p-4 text-left text-sm font-semibold text-white shadow-sm transition"
                          : "rounded-2xl border border-zinc-200 bg-white p-4 text-left text-sm font-medium text-zinc-800 transition hover:border-purple-300 hover:bg-purple-50/50"
                      }
                    >
                      <div className="flex items-center justify-between">
                        <span>{goal}</span>
                        {selected && <Check className="h-4 w-4 stroke-[3]" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <h2 className="mb-3 text-sm font-semibold text-zinc-900">
                Which platforms do you want to use?
              </h2>

              <div className="grid gap-3 sm:grid-cols-2">
                {platformOptions.map((platform) => {
                  const selected = data.platforms.includes(platform);

                  return (
                    <button
                      type="button"
                      key={platform}
                      onClick={() =>
                        toggleArrayValue("platforms", platform)
                      }
                      className={
                        selected
                          ? "rounded-2xl border-2 border-purple-600 bg-purple-600 p-4 text-left text-sm font-semibold text-white shadow-sm transition"
                          : "rounded-2xl border border-zinc-200 bg-white p-4 text-left text-sm font-medium text-zinc-800 transition hover:border-purple-300 hover:bg-purple-50/50"
                      }
                    >
                      <div className="flex items-center justify-between">
                        <span>{platform}</span>
                        {selected && <Check className="h-4 w-4 stroke-[3]" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* STEP 4 */}
        {currentStep === 4 && (
          <div className="space-y-6">
            <div>
              <label className="mb-2 block text-sm font-semibold text-zinc-900">
                Brand information
              </label>

              <textarea
                value={data.description}
                onChange={(event) =>
                  updateField("description", event.target.value)
                }
                placeholder="Describe your brand voice, style, positioning, products and anything else the AI should know."
                rows={6}
                className="w-full resize-none rounded-xl border border-zinc-200 bg-white p-4 text-sm text-zinc-900 outline-none transition focus:border-purple-600 focus:ring-2 focus:ring-purple-100 placeholder:text-zinc-400"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-semibold text-zinc-900">
                Product catalogue
              </label>

              <label className="flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed border-purple-200 bg-purple-50/40 px-6 py-10 text-center transition hover:border-purple-400 hover:bg-purple-50">
                <Upload className="mb-3 h-8 w-8 text-purple-600" />

                <span className="text-sm font-bold text-zinc-900">
                  {data.catalogueFile
                    ? data.catalogueFile.name
                    : "Upload your catalogue"}
                </span>

                <span className="mt-1 text-xs text-zinc-500">
                  Supports PDF, CSV, XLSX or Images
                </span>

                <input
                  type="file"
                  className="hidden"
                  accept=".pdf,.csv,.xlsx,.xls,.png,.jpg,.jpeg,.webp"
                  onChange={(event) =>
                    updateField(
                      "catalogueFile",
                      event.target.files?.[0] ?? null,
                    )
                  }
                />
              </label>
            </div>
          </div>
        )}

        {/* Navigation Actions */}
        <div className="mt-10 flex items-center justify-between border-t border-zinc-100 pt-6">
          <button
            type="button"
            onClick={previousStep}
            disabled={currentStep === 1}
            className="inline-flex h-11 items-center gap-2 rounded-xl border border-zinc-200 bg-white px-5 text-sm font-semibold text-zinc-700 transition hover:bg-zinc-50 disabled:pointer-events-none disabled:opacity-40"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </button>

          {currentStep < steps.length ? (
            <button
              type="button"
              onClick={nextStep}
              className="inline-flex h-11 items-center gap-2 rounded-xl bg-purple-600 px-6 text-sm font-semibold text-white transition hover:bg-purple-700 shadow-md shadow-purple-200"
            >
              Continue
              <ArrowRight className="h-4 w-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={completeOnboarding}
              className="inline-flex h-11 items-center gap-2 rounded-xl bg-purple-600 px-6 text-sm font-semibold text-white transition hover:bg-purple-700 shadow-md shadow-purple-200"
            >
              Complete setup
              <Check className="h-4 w-4" />
            </button>
          )}
        </div>

      </div>
    </div>
  );
}
